# node-express-helloworld

node.js express helloworld sample

build: express --view=pug helloworld
cd helloworld && npm install

run: DEBUG=helloworld:\* npm start
